=== Artistic Blog ===

Contributors: bizbergthemes
Tags: custom-logo,custom-menu,featured-images,threaded-comments,translation-ready,left-sidebar,right-sidebar,grid-layout,theme-options,blog,news,portfolio
Requires at least: 4.9
Tested up to: 5.7
Requires PHP: 5.6
Author URI: https://bizbergthemes.com/
Theme URI: https://bizbergthemes.com/downloads/artistic-blog/
License: GNU General Public License v3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

== Description ==

Artistic Blog Dark is a clean and minimal blog theme for perfect for writers who need to create personal blog site with simple creative features and effects to make readers feel the pleasure of reading blog posts and articles, Artistic Blog theme mixes between modern, classic and minimal styles and will help you create a simple and clean blog, if you are a blogger, then it’s a perfect choice for you if you don’t need to have any experiment to setup your WordPress Artistic Blog, it’s super simple and easy to setup, you will get high quality, responsive, well crafted blog out of the box to make writers only focuses on writing content, and it has great typography to make your fans and followers focus on every word you write. However, the child theme comes with a dark color scheme. Dark color schemes are quite popular and trending nowadays on top charts as it is considered to be a bold design trend and also they’re easy on the eye. If you love dark theme for your blog or corporate site.

== License ==

Bizberg WordPress Theme, Copyright 2021 Bizberg Themes
Bizberg is distributed under the terms of the GNU General Public License v3

Artistic Blog WordPress Theme is child theme of Bizberg WordPress Theme, Copyright 2021 Bizberg Themes
Artistic Blog WordPress Theme is distributed under the terms of the GNU GPL

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Screenshots ==

Image for theme screenshot, Copyright Pxhere
License: Creative Commons CC0 license
Source: https://pxhere.com/en/photo/922038

Image for theme screenshot, Copyright Pxhere
License: Creative Commons CC0 license
Source: https://pxhere.com/en/photo/7835

Image for theme screenshot, Copyright Pxhere
License: Creative Commons CC0 license
Source: https://pxhere.com/en/photo/948906

Image for theme screenshot, Copyright Pxhere
License: Creative Commons CC0 license
Source: https://pxhere.com/en/photo/1071666

Image for theme screenshot, Copyright Pxhere
License: Creative Commons CC0 license
Source: https://pxhere.com/en/photo/100901

Images in folder, Copyright Pxhere
License: Creative Commons CC0 license
Source: https://pxhere.com/en/photo/14200
Source: https://pxhere.com/en/photo/795999
Source: https://pxhere.com/en/photo/451320