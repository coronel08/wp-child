<?php if (is_active_sidebar( 'wc-sidebar' )): ?>

    <div class="wrapper bg-light p-3" id="wrapper-main-sidebar-widgets">
    
        <?php dynamic_sidebar( 'wc-sidebar' ); ?>
    
    </div>

<?php endif ?>
		