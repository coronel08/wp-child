<?php
//Talk is silver
//silence is golden.
   